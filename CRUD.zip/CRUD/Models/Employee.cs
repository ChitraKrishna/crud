﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter firstname.")]
        [StringLength(100)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter lastname.")]
        [StringLength(100)]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Please enter age.")]
        public string Age { get; set; }
        
        public string Gender { get; set; }

     
        public string IsActive { get; set; }

    }
}
