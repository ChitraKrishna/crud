﻿using CRUD.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Controllers
{
    public class EmployeeController : Controller
    {
        public ApplicationDbContext dbcontext;
        public EmployeeController(ApplicationDbContext _dbContext)
        {
            this.dbcontext = _dbContext;
        }

        public IActionResult Index()
        {
            List<Employee> emp = dbcontext.employees.ToList();
            return View(emp);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            if (ModelState.IsValid)
            {
                dbcontext.employees.Add(e);
                dbcontext.SaveChanges();
                return RedirectToAction("Index");

            }
            else
            {
                return View(e);
            }
        }
        [HttpGet]
        public IActionResult Update(int id)
        {
            var updateEmp = dbcontext.employees.SingleOrDefault(e => e.Id == id);
            return View(updateEmp);
        }
        [HttpPost]
        public IActionResult Update(Employee e)
        {
            dbcontext.employees.Update(e);
            dbcontext.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult delete(int id)
        {
            var deleteEmp = dbcontext.employees.SingleOrDefault(e => e.Id == id);
            dbcontext.employees.Remove(deleteEmp);
            dbcontext.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult View(int id)
        {
            var ViewEmp = dbcontext.employees.SingleOrDefault(e => e.Id == id);
            return View(ViewEmp);
        }


    }
}





